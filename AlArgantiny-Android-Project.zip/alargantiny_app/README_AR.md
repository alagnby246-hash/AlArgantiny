# الارجنتيني — نسخة Android

ده مشروع Android جاهز لفتحه في Android Studio وتحويله إلى APK.

- اسم التطبيق: الارجنتيني
- الأيقونة: الصورة المختارة
- المحتوى: يفتح الموقع الأصلي داخل التطبيق بدون تعديل محتواه
- الرابط: https://weekv4blkbvr6.kimi.page/

افتح المجلد في Android Studio ثم Build > Build APK(s).
